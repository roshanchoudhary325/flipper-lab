
const dm=document.getElementsByClassName('button')
dm.addEventListener("click",()=>{
  alert("hu")
}
)